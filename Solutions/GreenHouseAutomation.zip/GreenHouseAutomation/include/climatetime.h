#ifndef CLIMATETIME_H
#define CLIMATETIME_H

struct Time {
    int hour;
    int minute;
    int seconds;
};
#endif
