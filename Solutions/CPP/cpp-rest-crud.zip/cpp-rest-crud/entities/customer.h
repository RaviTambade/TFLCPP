#include <string>
class Customer {
public:
    int id;
    std::string name;
    int  age;
};
